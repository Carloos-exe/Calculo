public class Main{

    public static void main(String[] nousan) {

        DataSet dataSet = new DataSet();
        DiscreteMaths discreteMaths = new DiscreteMaths();

        SLR slr = new SLR(dataSet, discreteMaths);

        //slr.calculateIntersection();
       // discreteMaths.totalXY(dataSet.getX(), dataSet.getY());
        //discreteMaths.totalXSquared(dataSet.getX());
        slr.printRegEquation();
        slr.calculateSlope();

        //discreteMaths.totalXSquared(dataSet.getX());




    }
}