public class SLR {
    private int beta0;
    private int beta1;
    private DataSet dataSet;
    private DiscreteMaths discreteMaths;

    public SLR(DataSet dataSet, DiscreteMaths discreteMaths){
        beta0 = 0;
        beta1 = 0;
        this.dataSet = dataSet;
        this.discreteMaths = discreteMaths;
    }

    public void calculateIntersection(){
        // beta0 = ...
        System.out.println(discreteMaths.sumX(dataSet.getX()));
        System.out.println(discreteMaths.sumY(dataSet.getY()));

    }


    public float calculateSlope(){
        float nds = (discreteMaths.totalXY(dataSet.getX(), dataSet.getY()) * 9)-(discreteMaths.sumX(dataSet.getX())*discreteMaths.sumY(dataSet.getY()));
        System.out.println(": "+ nds);

        return nds;



    }

    public float printRegEquation(){
        float a,b,c;
      b=discreteMaths.totalXSquared(dataSet.getX()) * discreteMaths.totalXSquared(dataSet.getX());
        a = discreteMaths.totalXSquared(dataSet.getX())*9;
        c=b-a;

        System.out.println("a " + a);
        System.out.println("b "+ b);
        System.out.println("c "+ c);

        return c;

    }
    public void predict(float x){}

}